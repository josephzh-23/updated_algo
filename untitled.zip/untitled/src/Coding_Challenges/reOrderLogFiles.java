package Coding_Challenges;

import java.util.Arrays;

public class reOrderLogFiles {

    public String[] reorderLogFiles(String[] logs){
        Arrays.sort(logs, (log1, log2) ->{

            String split1[] = log1.split(" ", 2);
            String split2[] = log2.split(" ", 2);


        })
    }
}
