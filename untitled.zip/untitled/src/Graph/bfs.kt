import java.util.*

/*
Use q, pop from it and
    Time complexity of BFS for adj list  is O(V + E)

    O ( V ^2) when adj matrix is used

    V: the vertices and E: the edge
 */
internal class WeightedGraph( //number of nodes in the graph
        private val V: Int) {
    private val adj: Array<LinkedList<Int>> //adjacency list
    private val queue //maintaining a queue
            : Queue<Int>

    init {
        adj = arrayOf<LinkedList<Int>>()
        for (i in 0 until V) {
            adj[i] = LinkedList<Int>()
        }
        queue = LinkedList()
    }

    fun addEdge(v: Int, w: Int) {
        adj[v].add(w) //adding an edge to the adjacency list (edges are bidirectional in this example)
    }

    fun BFS(n: Int) {
        var n = n
        val nodes = BooleanArray(V) //initialize boolean array for holding the data
        var a = 0
        nodes[n] = true
        queue.add(n) //root node is added to the top of the queue
        while (queue.size != 0) {
            n = queue.poll() //remove the top element of the queue
            print("$n ") //print the top element of the queue
            for (i in adj[n].indices)  //iterate through the linked list and push all neighbors into queue
            {
                a = adj[n][i]
                if (!nodes[a]) //only insert nodes into queue if they have not been explored already
                {
                    nodes[a] = true
                    queue.add(a)
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            val graph = WeightedGraph(6)
            graph.addEdge(0, 1)
            graph.addEdge(0, 3)
            graph.addEdge(0, 4)
            graph.addEdge(4, 5)
            graph.addEdge(3, 5)
            graph.addEdge(1, 2)
            graph.addEdge(1, 0)
            graph.addEdge(2, 1)
            graph.addEdge(4, 1)
            graph.addEdge(3, 1)
            graph.addEdge(5, 4)
            graph.addEdge(5, 3)
            println("The Breadth First Traversal of the graph is as follows :")
            graph.BFS(0)
        }
    }
}