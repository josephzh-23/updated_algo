package Util
fun main() {
    var arr = arrayOf(intArrayOf(1, 2, 3), intArrayOf(4, 5, 6), intArrayOf(7, 8, 9))
    for (row in arr) {
        println(row.contentToString())
    }

    // ArrayOf      IntArray for declaring the function the actual type as
    // explained
    // Template to solving the 2d problem as in kotlin
//    val m = grid.size.kt
//    val n = grid[0].size.kt
//    val seen = Array(m) { IntArray(n) }
}
// Array<IntArray> this would be the 2d matrix as mentioned before