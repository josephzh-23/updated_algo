package Util

//Builds an empty array as described
val arr = arrayOf<Int>()
// can also do the following
val list = mutableListOf<Int>()

// Instead of the above can also do, if you know size.kt
var n = 4 ; var parents =IntArray(n) ; var size = IntArray(n)
fun main(){
    for (i in parents.indices) {
        parents[i] = i
        size[i] = 1
    }
}