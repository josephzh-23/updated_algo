package Util

import java.util.*


fun main(){

    var pq = PriorityQueue<Student>(5, StudentComparator())
    val student1 = Student("Nandini", 3.2)

    // Adding a student object containing fields
    // name and cgpa to priority queue

    // Adding a student object containing fields
    // name and cgpa to priority queue
    pq.add(student1)
    val student2 = Student("Anmol", 3.6)
    pq.add(student2)
    val student3 = Student("Palak", 4.0)
    pq.add(student3)

    while(!pq.isEmpty()){
        println(pq.poll().name)
    }

}

class Student    // A parameterized student constructor
(var name: String, var cgpa: Double)


// This would be in descending order, => basically a max queue (biggest
// come out first
class StudentComparator : Comparator<Student> {
    // Overriding compare()method of Comparator
    // for descending order of cgpa
    override fun compare(s1: Student, s2: Student): Int {
        if (s1.cgpa < s2.cgpa) return 1 else if (s1.cgpa > s2.cgpa) return -1
        return 0
    }
}

// Use the following would be fine