fun main(){
    val fruits = listOf("banana", "mango", "apple", "orange")

    // Until get to that point does not include though
    for (i in 0 until fruits.size) {
        print("${fruits[i]} ")
    }
}