fun main(){

    // Demonstrating Set using HashSet
    // Declaring object of type String
    val hash_Set: MutableSet<String> = HashSet()

    // Adding elements to the Set
    // using add() method

    // Adding elements to the Set
    // using add() method
    hash_Set.add("Geeks")
    hash_Set.add("For")
    hash_Set.add("Geeks")
    hash_Set.add("Example")
    hash_Set.add("Set")

    // Printing elements of HashSet object

    // Printing elements of HashSet object
    println(hash_Set)
}