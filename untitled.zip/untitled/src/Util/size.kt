

var list = mutableListOf<Int>(4)
