package Util

fun main() {
    var n =4
    var parents =IntArray(n)
    for (i in parents.indices) {
        parents[i] = i
        size[i] = 1
    }
}
